1  <?php
   2  /**
   3   * PHPMailer language file.  
   4   * English Version
   5   */
   6  
   7  $PHPMAILER_LANG = array();
   8  
   9  $PHPMAILER_LANG["provide_address"] = 'You must provide at least one ' .
  10                                       'recipient email address.';
  11  $PHPMAILER_LANG["mailer_not_supported"] = ' mailer is not supported.';
  12  $PHPMAILER_LANG["execute"] = 'Could not execute: ';
  13  $PHPMAILER_LANG["instantiate"] = 'Could not instantiate mail function.';
  14  $PHPMAILER_LANG["authenticate"] = 'SMTP Error: Could not authenticate.';
  15  $PHPMAILER_LANG["from_failed"] = 'The following From address failed: ';
  16  $PHPMAILER_LANG["recipients_failed"] = 'SMTP Error: The following ' .
  17                                         'recipients failed: ';
  18  $PHPMAILER_LANG["data_not_accepted"] = 'SMTP Error: Data not accepted.';
  19  $PHPMAILER_LANG["connect_host"] = 'SMTP Error: Could not connect to SMTP host.';
  20  $PHPMAILER_LANG["file_access"] = 'Could not access file: ';
  21  $PHPMAILER_LANG["file_open"] = 'File Error: Could not open file: ';
  22  $PHPMAILER_LANG["encoding"] = 'Unknown encoding: ';
  23  ?>